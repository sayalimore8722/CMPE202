 

public interface A2 {
 
}
 
