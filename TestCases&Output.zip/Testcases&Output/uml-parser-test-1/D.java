 

public class D {
 
	private A a;
	 
}
 
